#include <iostream>

using namespace std;

/** fun��o de inicializa��o do programa **/
int main() {

    int x, y;
    float z;

    cout << "Escreva 2 numeros inteiros e um real"
    cout << "x(inteiro) = "
    cin >> x;
    cout << "y(inteiro) = "
    cin >> y;
    cout << "z(real) = "
    cin z;

    cout <<
}
