#include <iostream>

using namespace std;

/** fun��o de inicializa��o do programa **/
int main() {

    double meter;

    cout << "\n\n\t\t\t\tWELCOME TO THE METER TO CENTIRMETER CONVERTOR!!" << endl;
    cout << "\n\nPUT THE NUMBER THAT YOU WANNA SEE IN CENTIMETER: ";
    cin >> meter;
    cout << meter << " METERS = " << meter * 100 << " CENTIMETERS" << endl;

}
